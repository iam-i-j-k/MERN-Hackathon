import React, { useContext } from 'react'
import { UserContext } from './context/UserContext';
import Cart from './components/user/Cart';
import Product from './components/user/Product';
import Navbar from './components/user/Navbar';
import CheckConnection from './components/common/CheckConnection';
import Login from './components/common/Login';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import LandingPage from './components/common/LandingPage';
import NotFound from './components/common/NotFound';
import Home from './components/user/Home';

const App = () => {

  const { user, setUser } = useContext(UserContext);


  return (
    <div>
      <Router>
        <CheckConnection />
        <Navbar />
        <Routes>
          <Route path='/' element={<LandingPage />} />
          <Route path='/login' element={<Login />} />
          <Route path='/home' element={<Home />} />
          <Route path='*' element={<NotFound />} />
        </Routes>
      </Router>
    </div>
  )
}

export default App